<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST["first-name"]));
    $last_name = htmlspecialchars(trim($_POST["last-name"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars(trim($_POST["message"]));
    $recipient = "info@hausverwaltung-natalie-frank.de";
    $subject = "Neue Anfrage von $name $last_name";
    $boundary = md5(time());
    $headers = "From: $name <$email>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    $email_content = "--$boundary\r\n";
    $email_content .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
    $email_content .= "Name: $name $last_name\n";
    $email_content .= "E-Mail: $email\n\n";
    $email_content .= "Nachricht:\n$message\n";

    $uploadDir = "uploads/";
    $file_attached = false;

    // Проверка и обработка загруженных файлов
    foreach ($_FILES['attachment']['tmp_name'] as $key => $tmp_name) {
        $file_name = $_FILES['attachment']['name'][$key];
        $file_size = $_FILES['attachment']['size'][$key];
        $file_tmp = $_FILES['attachment']['tmp_name'][$key];
        $file_type = $_FILES['attachment']['type'][$key];

        // Ограничение по типу файла
        $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'];
        if (!in_array($file_type, $allowed_types)) {
            echo "Ungültiges Dateiformat.";
            exit;
        }

        // Ограничение по размеру
        if ($file_size > 5 * 1024 * 1024) {  // 5MB
            echo "Datei zu groß (Max 5MB).";
            exit;
        }

        // Чтение и добавление файла в письмо
        $file_content = chunk_split(base64_encode(file_get_contents($file_tmp)));
        $email_content .= "--$boundary\r\n";
        $email_content .= "Content-Type: $file_type; name=\"$file_name\"\r\n";
        $email_content .= "Content-Disposition: attachment; filename=\"$file_name\"\r\n";
        $email_content .= "Content-Transfer-Encoding: base64\r\n\r\n";
        $email_content .= $file_content . "\r\n";
        $file_attached = true;
    }

    $email_content .= "--$boundary--";

    // Отправка письма
    if (mail($recipient, $subject, $email_content, $headers)) {
        echo "Vielen Dank! Ihre Nachricht wurde gesendet.";
    } else {
        echo "Fehler beim Senden der Nachricht.";
    }
} else {
    echo "Hoppla! Etwas ist schief gelaufen.";
}
?>